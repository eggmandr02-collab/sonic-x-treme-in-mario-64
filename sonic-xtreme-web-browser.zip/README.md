# Sonic X-treme browser reconstruction

This is a playable, browser-based Three.js reconstruction of the supplied v37 one-level technical demo. It uses the supplied level definition, level map, Sonic animation frames, environment textures, and enemy artwork. The PCX images have been converted to PNG for browser loading; the level map is still treated as image data and sampled by the course builder.

## Important scope note

This is not a 1:1 port of the original game engine. The supplied archive contains assets and demo data, but no engine source or build project, so the original executable was not decompiled or run. This project rebuilds the playable scene and controls in new Three.js code. It does not include the original EXE or DLLs.

The PNG conversion preserves the source images' dimensions and visual detail; changing the file format does not upscale the original art.

## Run it

Extract the ZIP, open a terminal in the extracted folder, then start a local static server:

```sh
python3 -m http.server 8000
```

Open <http://localhost:8000> in a modern browser. Three.js/WebGL is used when available; a Canvas 2D compatibility renderer keeps the course playable when WebGL is unavailable. Do not open `index.html` directly as a `file://` URL; the game loads its level files with browser fetch requests.

## Controls

- **W / Up:** run faster
- **S / Down:** slow down
- **A / Left** and **D / Right:** move across the course
- **Z:** jump
- **X:** rotate the world
- **Tab:** restart
- **Escape:** pause or resume
- On touch screens, use the on-screen left/right, run, jump, and rotate buttons.

The package was prepared for sharing with the asset redistribution permission confirmed by the project owner. Check applicable rights before redistributing it further.
